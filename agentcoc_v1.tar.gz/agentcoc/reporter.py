"""
AgentCoC EvidentiaryReporter
==============================
Scores a DetectionResult + EventLedger against the four-stage
FRE evidentiary gatekeeping test, then renders two outputs:

  1. Rich terminal table — immediate human-readable verdict
  2. HTML incident report — archivable, shareable forensic document

The four stages (from the research framework):
  Stage 1 — Authentication (FRE 901/902): is the evidence provably untampered?
  Stage 2 — Reliability (Daubert): is the attribution method scientifically validated?
  Stage 3 — Relevance: does it answer the causal "why", not just "where"?
  Stage 4 — Chain of custody: is the ENTIRE trace accounted for?
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .detector import DetectionResult
from .ledger import EventLedger


# ------------------------------------------------------------------ #
#  Verdict enum                                                       #
# ------------------------------------------------------------------ #

class Verdict(str, Enum):
    PASS        = "PASS"
    PARTIAL     = "PARTIAL"
    FAIL        = "FAIL"
    CONDITIONAL = "CONDITIONAL"


_VERDICT_COLORS = {
    Verdict.PASS:        "green",
    Verdict.PARTIAL:     "yellow",
    Verdict.FAIL:        "red",
    Verdict.CONDITIONAL: "orange3",
}

_VERDICT_EMOJI = {
    Verdict.PASS:        "✅",
    Verdict.PARTIAL:     "⚠️",
    Verdict.FAIL:        "❌",
    Verdict.CONDITIONAL: "🔶",
}

# HTML colours for the report
_VERDICT_HTML_COLORS = {
    Verdict.PASS:        "#2E7D32",
    Verdict.PARTIAL:     "#E65100",
    Verdict.FAIL:        "#B71C1C",
    Verdict.CONDITIONAL: "#F57F17",
}


# ------------------------------------------------------------------ #
#  Stage result dataclass                                             #
# ------------------------------------------------------------------ #

@dataclass
class StageResult:
    stage_number: int
    stage_name:   str
    legal_basis:  str
    verdict:      Verdict
    finding:      str   # one-sentence verdict explanation
    detail:       str   # fuller forensic analysis


# ------------------------------------------------------------------ #
#  EvidentiaryReporter                                                #
# ------------------------------------------------------------------ #

class EvidentiaryReporter:
    """
    Applies the four-stage FRE evidentiary gatekeeping test to an incident.

    Usage:
        reporter = EvidentiaryReporter(output_dir=Path("reports"))
        reporter.generate(
            detection   = detection_result,
            ledger      = event_ledger,
            case_id     = "CASE-001",
            user_message = "What is my balance?",
        )
    """

    def __init__(self, output_dir: Path = Path("reports")) -> None:
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._console = Console()

    # ---------------------------------------------------------------- #
    #  Main entry point                                                 #
    # ---------------------------------------------------------------- #

    def generate(
        self,
        detection:    DetectionResult,
        ledger:       EventLedger,
        case_id:      str,
        user_message: str,
    ) -> Path:
        """
        Score the incident and produce terminal + HTML outputs.

        Args:
            detection:    Result from InjectionDetector.
            ledger:       The complete tamper-evident event ledger.
            case_id:      Unique identifier for this incident.
            user_message: The original user query that triggered the session.

        Returns:
            Path to the generated HTML report file.
        """
        stages = self._score_all_stages(detection, ledger)
        report_path = self._render_html(detection, ledger, stages, case_id, user_message)
        self._render_terminal(detection, stages, case_id, user_message, report_path)
        return report_path

    # ---------------------------------------------------------------- #
    #  4-Stage scoring                                                  #
    # ---------------------------------------------------------------- #

    def _score_all_stages(
        self,
        detection: DetectionResult,
        ledger:    EventLedger,
    ) -> List[StageResult]:
        return [
            self._score_stage1(ledger),
            self._score_stage2(detection),
            self._score_stage3(detection),
            self._score_stage4(ledger),
        ]

    def _score_stage1(self, ledger: EventLedger) -> StageResult:
        """
        Stage 1 — Authentication (FRE 901/902)
        Can the proponent prove this evidence is what it claims to be?
        → Verify the SHA-256 hash chain is unbroken.
        """
        chain_valid   = ledger.verify_chain()
        entry_count   = len(ledger)
        latest_hash   = ledger.get_all()[-1].entry_hash if ledger.get_all() else "N/A"

        if chain_valid:
            verdict = Verdict.PASS
            finding = "Hash chain is intact across all events — evidence is verifiably untampered."
            detail  = (
                f"The EventLedger contains {entry_count} sealed entries. "
                f"SHA-256 hash chain replay confirmed integrity end-to-end. "
                f"Terminal hash: {latest_hash[:16]}… "
                "This satisfies FRE 901(b)(9) (process or system producing accurate result) "
                "and FRE 902 self-authentication via cryptographic seal."
            )
        else:
            verdict = Verdict.FAIL
            finding = "Hash chain verification FAILED — the ledger has been modified after the fact."
            detail  = (
                "At least one entry's recomputed hash does not match its stored hash. "
                "This evidence cannot be authenticated and would be inadmissible under FRE 901. "
                "The modification point should be investigated as a separate incident."
            )

        return StageResult(1, "Authentication", "FRE 901/902", verdict, finding, detail)

    def _score_stage2(self, detection: DetectionResult) -> StageResult:
        """
        Stage 2 — Reliability (Daubert v. Merrell Dow, 509 U.S. 579)
        Is the methodology scientifically valid with known, tested error rates?
        → Counterfactual replay is sound in principle, but lacks a peer-reviewed
          false-positive rate. This is the critical gap identified by the research.
        """
        if detection.counterfactual_ran and detection.diverged:
            verdict = Verdict.PARTIAL
            finding = (
                "Counterfactual replay confirms causal attribution, but no peer-reviewed "
                "error rate exists for this method — Daubert reliability is PARTIAL."
            )
            detail  = (
                "The counterfactual methodology (re-run without suspected injection → compare) "
                "is logically sound and mirrors accepted causal inference practice. "
                "However, Daubert requires a known, tested error rate and peer-review. "
                "Current tools (AttriGuard, AgentSentry) report confidence scores, not "
                "validated FP/FN rates across held-out ground-truth datasets. "
                "RECOMMENDATION: Validate attribution error rates on a labelled AgentDojo "
                "split before using this as standalone legal evidence."
            )
        elif detection.heuristic_triggered and not detection.counterfactual_ran:
            verdict = Verdict.PARTIAL
            finding = "Heuristic detection only — counterfactual replay not attempted. Reliability is PARTIAL."
            detail  = (
                "Pattern matching detected an injection candidate, but causal attribution via "
                "counterfactual replay was not executed. Without replay, the attribution is "
                "observational rather than causal. Daubert requires testable methodology; "
                "heuristics alone do not meet this standard."
            )
        else:
            verdict = Verdict.FAIL
            finding = "No injection detected — reliability assessment N/A for this session."
            detail  = "No attribution method was triggered. Stage 2 is not applicable."

        return StageResult(2, "Reliability", "Daubert standard", verdict, finding, detail)

    def _score_stage3(self, detection: DetectionResult) -> StageResult:
        """
        Stage 3 — Relevance
        Does the evidence actually resolve the disputed causal question?
        → Attribution must answer "why the agent acted" not just "where the input was."
        """
        if not detection.flagged:
            return StageResult(
                3, "Relevance", "FRE 401/402",
                Verdict.PASS,
                "No injection — no causal question to resolve. Clean session.",
                "No anomalous causal chain was detected. The agent's actions are attributable "
                "entirely to the authenticated user's explicit instruction."
            )

        if detection.diverged:
            verdict = Verdict.PARTIAL
            finding = (
                "Attribution identifies the causal input (where), but cannot fully explain "
                "why the agent's policy treated the injection as trusted instruction."
            )
            detail  = (
                f"The counterfactual replay confirmed that removing the flagged content "
                f"('…{detection.flagged_content[:60]}…') changed the agent's output. "
                "This answers the 'which input caused the deviation' question. "
                "However, it does not fully explain the model's internal trust mechanism — "
                "i.e., why the system prompt's security rules were overridden. "
                "A full mechanistic explanation (attention weights, layer attribution) would "
                "be needed to fully satisfy the causal 'why' for legal proceedings."
            )
        else:
            verdict = Verdict.PARTIAL
            finding = "Pattern matched, but outputs did not diverge — causal link is inconclusive."
            detail  = (
                "An injection pattern was detected in the context, but removing it did not "
                "change the agent's output. This weakens the causal relevance argument. "
                "The agent may have already had the instruction from another source, or the "
                "model ignored the injection. Relevance is partial at best."
            )

        return StageResult(3, "Relevance", "FRE 401/402", verdict, finding, detail)

    def _score_stage4(self, ledger: EventLedger) -> StageResult:
        """
        Stage 4 — Chain of Custody (ACPO/PACE / ISO 27037)
        Is the ENTIRE sequence of events accounted for with no gaps?
        → Check that all required event types are present in the ledger.
        """
        all_types  = {e.event_type for e in ledger.get_all()}
        chain_ok   = ledger.verify_chain()

        # Required event types for a complete custody record
        required_types = {"context_read", "llm_call", "tool_call"}
        present_types  = required_types & all_types
        missing_types  = required_types - all_types

        has_counterfactual = "counterfactual" in all_types
        has_flag           = "injection_flag" in all_types

        if chain_ok and not missing_types and has_counterfactual:
            verdict = Verdict.PASS
            finding = "Complete, unbroken event chain — all mandatory event types present and hash-verified."
            detail  = (
                f"All {len(ledger)} events are sealed and hash-chained. "
                f"Event types recorded: {sorted(all_types)}. "
                "The chain runs from initial context ingestion through LLM inference, "
                "tool execution, injection detection, and counterfactual replay. "
                "No gaps detected. This satisfies ISO/IEC 27037:2012 digital evidence "
                "guidelines and ACPO Principle 1 (no alteration of original evidence)."
            )
        elif chain_ok and not missing_types and not has_counterfactual:
            verdict = Verdict.CONDITIONAL
            finding = (
                "Chain is complete for standard actions, but counterfactual replay "
                "events are absent — custody is CONDITIONAL on whether replay was needed."
            )
            detail  = (
                f"Event types present: {sorted(all_types)}. "
                "No injection was detected so no counterfactual was run. "
                "If this session is later disputed, the absence of a replay event means "
                "the chain is complete but cannot prove absence of injection causation. "
                "RECOMMENDATION: Run InjectionDetector on all sessions, even clean ones, "
                "to produce a complete negative finding record."
            )
        elif missing_types:
            verdict = Verdict.PARTIAL
            finding = f"Chain is missing event types: {missing_types} — custody record is incomplete."
            detail  = (
                f"Expected event types {required_types} but only found {present_types}. "
                "Missing events represent gaps in the custody record that could be challenged "
                "in legal proceedings as evidence that events occurred outside the monitored scope."
            )
        else:
            verdict = Verdict.FAIL
            finding = "Hash chain broken AND missing event types — chain of custody fails."
            detail  = "The ledger cannot verify integrity and is missing critical event types."

        return StageResult(4, "Chain of Custody", "ACPO / ISO 27037", verdict, finding, detail)

    # ---------------------------------------------------------------- #
    #  Rich terminal output                                             #
    # ---------------------------------------------------------------- #

    def _render_terminal(
        self,
        detection:   DetectionResult,
        stages:      List[StageResult],
        case_id:     str,
        user_message: str,
        report_path: Path,
    ) -> None:
        console = self._console

        # Header
        console.print()
        console.rule("[bold cyan]AgentCoC — Evidentiary Incident Report[/bold cyan]")
        console.print(f"[bold]Case ID:[/bold]      {case_id}")
        console.print(f"[bold]Timestamp:[/bold]    {datetime.now(timezone.utc).isoformat()}")
        console.print(f"[bold]User Query:[/bold]   {user_message[:80]}…" if len(user_message) > 80 else f"[bold]User Query:[/bold]   {user_message}")
        console.print()

        # Injection summary
        if detection.flagged:
            status_text = Text("⚠️  PROMPT INJECTION DETECTED", style="bold red")
            console.print(Panel(
                f"{status_text}\n\n"
                f"[bold]Summary:[/bold]     {detection.summary}\n"
                f"[bold]Method:[/bold]      {detection.method}\n"
                f"[bold]Confidence:[/bold]  {detection.confidence}\n"
                f"[bold]Flagged:[/bold]     {detection.flagged_content[:80]}",
                title="Detection Result",
                border_style="red",
            ))
        else:
            console.print(Panel(
                "✅  [bold green]No injection detected — clean session.[/bold green]\n\n"
                f"[bold]Summary:[/bold] {detection.summary}",
                title="Detection Result",
                border_style="green",
            ))

        console.print()

        # 4-Stage scoring table
        table = Table(
            title="4-Stage Evidentiary Gatekeeping Assessment",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold white on dark_blue",
            expand=True,
        )
        table.add_column("Stage", style="bold", width=6,  justify="center")
        table.add_column("Name",  width=22)
        table.add_column("Legal Basis", width=20)
        table.add_column("Verdict", width=14, justify="center")
        table.add_column("Finding", no_wrap=False)

        for s in stages:
            color   = _VERDICT_COLORS[s.verdict]
            emoji   = _VERDICT_EMOJI[s.verdict]
            verdict = Text(f"{emoji} {s.verdict.value}", style=f"bold {color}")
            table.add_row(str(s.stage_number), s.stage_name, s.legal_basis, verdict, s.finding)

        console.print(table)
        console.print()
        console.print(f"[dim]📄 Full HTML report saved to: {report_path}[/dim]")
        console.print()
        console.rule("[dim cyan]End of Report[/dim cyan]")
        console.print()

    # ---------------------------------------------------------------- #
    #  HTML report                                                      #
    # ---------------------------------------------------------------- #

    def _render_html(
        self,
        detection:    DetectionResult,
        ledger:       EventLedger,
        stages:       List[StageResult],
        case_id:      str,
        user_message: str,
    ) -> Path:
        html = _build_html(detection, ledger, stages, case_id, user_message)
        path = self._output_dir / f"incident_{case_id}.html"
        path.write_text(html, encoding="utf-8")
        return path.resolve()


# ------------------------------------------------------------------ #
#  HTML builder (no external template file needed)                   #
# ------------------------------------------------------------------ #

def _build_html(
    detection:    DetectionResult,
    ledger:       EventLedger,
    stages:       List[StageResult],
    case_id:      str,
    user_message: str,
) -> str:
    ts = datetime.now(timezone.utc).isoformat()

    verdict_bg = {
        Verdict.PASS:        "#E8F5E9",
        Verdict.PARTIAL:     "#FFF3E0",
        Verdict.FAIL:        "#FFEBEE",
        Verdict.CONDITIONAL: "#FFFDE7",
    }

    # Build stage rows
    stage_rows = ""
    for s in stages:
        color = _VERDICT_HTML_COLORS[s.verdict]
        bg    = verdict_bg[s.verdict]
        stage_rows += f"""
        <tr style="background:{bg}">
          <td style="font-weight:bold;text-align:center">{s.stage_number}</td>
          <td><strong>{s.stage_name}</strong></td>
          <td style="font-style:italic;color:#555">{s.legal_basis}</td>
          <td style="color:{color};font-weight:bold;text-align:center">
            {_VERDICT_EMOJI[s.verdict]} {s.verdict.value}
          </td>
          <td>{s.finding}</td>
        </tr>
        <tr style="background:#fafafa">
          <td></td>
          <td colspan="4" style="font-size:0.9em;color:#444;padding:8px 12px">{s.detail}</td>
        </tr>"""

    # Ledger entries
    ledger_rows = ""
    for e in ledger.get_all():
        ledger_rows += f"""
        <tr>
          <td style="font-size:0.8em;color:#666">{e.timestamp}</td>
          <td><code style="background:#f0f0f0;padding:2px 6px;border-radius:3px">{e.event_type}</code></td>
          <td style="font-family:monospace;font-size:0.8em;color:#888">{e.entry_hash[:24]}…</td>
          <td style="font-size:0.85em">{json.dumps(e.content)[:120]}…</td>
        </tr>"""

    detection_color = "#B71C1C" if detection.flagged else "#2E7D32"
    detection_label = "⚠️ INJECTION DETECTED" if detection.flagged else "✅ CLEAN SESSION"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AgentCoC — Incident Report {case_id}</title>
<style>
  body {{ font-family: system-ui, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; color: #212121; }}
  .container {{ max-width: 1100px; margin: 0 auto; background: white; border-radius: 8px; padding: 32px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }}
  h1 {{ color: #00897B; margin-top: 0; }}
  h2 {{ color: #4E2C0A; border-bottom: 2px solid #00897B; padding-bottom: 6px; }}
  .meta {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px; background: #f9f9f9; padding: 16px; border-radius: 6px; margin-bottom: 24px; font-size: 0.9em; }}
  .meta span {{ color: #555; }}
  .detection-banner {{ padding: 16px 20px; border-radius: 6px; margin-bottom: 24px; font-size: 1.05em; font-weight: bold; color: white; background: {detection_color}; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.9em; }}
  th {{ background: #00897B; color: white; padding: 10px 12px; text-align: left; }}
  td {{ padding: 8px 12px; border-bottom: 1px solid #eee; vertical-align: top; }}
  .footer {{ margin-top: 32px; font-size: 0.8em; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 16px; }}
</style>
</head>
<body>
<div class="container">
  <h1>🔍 AgentCoC — Evidentiary Incident Report</h1>

  <div class="meta">
    <div><strong>Case ID:</strong> <span>{case_id}</span></div>
    <div><strong>Timestamp:</strong> <span>{ts}</span></div>
    <div><strong>User Message:</strong> <span>{user_message}</span></div>
    <div><strong>Events Sealed:</strong> <span>{len(ledger)}</span></div>
    <div><strong>Chain Integrity:</strong> <span>{'✅ Verified' if ledger.verify_chain() else '❌ BROKEN'}</span></div>
    <div><strong>Detection Method:</strong> <span>{detection.method}</span></div>
  </div>

  <div class="detection-banner">{detection_label} — {detection.summary}</div>

  <h2>4-Stage Evidentiary Gatekeeping Assessment</h2>
  <table>
    <thead>
      <tr>
        <th>#</th><th>Stage</th><th>Legal Basis</th><th>Verdict</th><th>Finding</th>
      </tr>
    </thead>
    <tbody>{stage_rows}</tbody>
  </table>

  <h2 style="margin-top:32px">Event Ledger (Tamper-Evident Log)</h2>
  <table>
    <thead>
      <tr><th>Timestamp</th><th>Type</th><th>Entry Hash (truncated)</th><th>Content Preview</th></tr>
    </thead>
    <tbody>{ledger_rows}</tbody>
  </table>

  <div class="footer">
    Generated by AgentCoC v1.0 · Deep Learning Indaba 2026 · Poster GP-32 ·
    FRE 901/902 · Daubert v. Merrell Dow (1993) · EU AI Act Art. 12
  </div>
</div>
</body>
</html>"""
